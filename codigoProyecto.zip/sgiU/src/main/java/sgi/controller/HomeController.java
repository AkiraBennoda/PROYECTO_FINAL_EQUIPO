package sgi.controller;

import org.springframework.stereotype.Controller;





@Controller
public class HomeController {
	
	
	
}
