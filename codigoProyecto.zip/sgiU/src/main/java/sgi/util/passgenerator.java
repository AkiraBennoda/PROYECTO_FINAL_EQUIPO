package sgi.util;


import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class passgenerator {

    public static void main(String ...args) {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder(4);
     	System.out.println(bCryptPasswordEncoder.encode("1234"));
    }
}